public class StringExample{

public static String getMyAwesomeString(){
    int javaVersion = 9;
    String myAwesomeString = "I love " + "Java " + javaVersion + " high performance book by Mayur Ramgir" ;
    return myAwesomeString;
}

}